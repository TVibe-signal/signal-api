TVibe Signal — part136 wallet_intel patch
==========================================

What changed
- extensions.py: inserted part136 BEFORE MCP (# --- part7 ---)
- Adds research shadow: deployer reputation (pump.fun) + bundle/fresh-wallet heuristic
- Response field: wallet_intel (shadow=true)
- Endpoint: GET /stats/wallet-intel
- Does NOT change filter.pass / hard blockers
- VERSION set to 3.0.7 in this block (later loaders may override if any)

Deploy
1. Replace extensions.py on GitHub (same path as now)
2. Redeploy Render
3. Test:
   GET /omni?mint=<pump_mint>
   look for "wallet_intel"
   GET /stats/wallet-intel

Env (optional, Render)
- WI_ENABLED=1   (default on)
- WI_ESCALATE=0  set to 1 to also append soft cautions into decision.cautions

Notes
- main.py / core.py / features.py unchanged
- Keep this block above MCP or MCP mount order breaks
